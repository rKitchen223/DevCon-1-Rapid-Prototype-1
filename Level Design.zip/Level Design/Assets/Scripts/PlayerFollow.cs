using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerFollow : MonoBehaviour
{
    //Every object in Unity has a transform
    //This will be where the camera points
    private Transform target;

    //Offset if you would like the camera to not be right at the player at all times.
    //Vector3.zero is (0, 0, 0)
    //Despite being in 2D, we have to use Vector3because transforms are always Vector3
    public Vector3 offset = Vector3.zero;

    //Smoothing for the movement
    public float smoothFactor = 2f;

    // Start is called before the first frame update
    void Start()
    {
        //Find the player by the tag and hen grab its transform
        target = GameObject.FindGameObjectWithTag("Player").transform;
    }

    // Update is called once per frame AFTER update
    void LateUpdate()
    {
        //Temporary variable to "spit apart" the Vector3. This is to make sure the camera's z-position is not the same as
        //the player, meaning it won't render!
                        //Set the position to target's x and y, but maintain the camera's z
        Vector3 targetPos = new Vector3(target.position.x, target.position.y, transform.position.z);

        //Change th camera's position to the new target at the smoothing rate This uses Linear Interpolation which is a smooth
        //transitin between vectors. LERP is a fun word.
        transform.position = Vector3.Lerp(transform.position, targetPos + offset, smoothFactor * Time.deltaTime);
    }
}
