using UnityEngine;
using UnityEngine.SceneManagement;

public class FinalSceneManager : MonoBehaviour
{
    void Update()
    {
        // If the player presses R, reset the game by loading the first level
        if (Input.GetKeyDown(KeyCode.R))
        {
            SceneManager.LoadScene("Level1"); 
        }
    }
}
