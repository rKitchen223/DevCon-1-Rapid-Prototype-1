using UnityEngine;
using UnityEngine.SceneManagement;

public class Die : MonoBehaviour
{
    public string finishSceneName = "FinishScene";

    // This function is called when another collider enters this trigger collider
    private void OnTriggerEnter2D(Collider2D collision)
    {
        // Check if the object colliding has the "Player" tag
        if (collision.CompareTag("Player"))
        {
            // Load the finish scene
            SceneManager.LoadScene(finishSceneName);
        }
    }
}
