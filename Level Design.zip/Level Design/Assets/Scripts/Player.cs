using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using Unity.VisualScripting;
using UnityEngine;

public class Player : MonoBehaviour
{
    //Global Variables
    //Access RigidBody2D component
    private Rigidbody2D rb2d;

    //Movement Variables
    public float moveSpeed = 8f;
    public float sprintFactor = 1.5f;
    public bool isSprinting = false;

    //Jumping variables
    public float jumpHeight = 5;
    public float fallingMultiplier = 2.5f; //To make the player speed up on decent
    public float lowjumpMultiplier = 1.5f; //If he player taps jumo itead of holding

    public bool isGrounded; //Bool to make sure the player is on the ground
    public LayerMask groundLayer;

    // -------------------- ADDED FOR POWERUP --------------------
    // A flag to check if we already collected the powerup
    private bool hasPowerup = false;
    // -----------------------------------------------------------

    // Start is called before the first frame update
    void Start()
    {
        //Initialization is when you give a variablea value.
        //The Rigidbody2D component is on the same object as this script.
        //GetComponent<Rigidbody2D> means "ook for a Rigidbody2D component"
        rb2d = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        //Local float variable called h
        float h = Input.GetAxis("Horizontal");

        //Check for ground usig a Raycast
        //Parameters are (starting point, direction, length, layer mask)
        //This is a ray that starts at the plaer position, points downward
        //isa length of 1.5 units, and only checks for the groundLayer
        isGrounded = Physics2D.Raycast(transform.position, Vector2.down, 1.5f, groundLayer);

        //Call the Movement function and send it the h value.
        Movement(h);

        //Call the HandleJump function
        HandleJump();
    }

    //Create the Movement function
    void Movement(float hSpeed)
    {
        //Move the player using the Rigidbody2D
        //Vector2 is x and y. This is setting thr rb2d.velocity to x = horizontal input
        //* moveSpeed, and y = whatever the rb2d's y velocity is at the time
        rb2d.velocity = new Vector2(hSpeed * moveSpeed, rb2d.velocity.y);
    }

    void HandleJump()
    {
        //Make sure the player isGrounde first (see Update) and presing space
        if (isGrounded && Input.GetKeyDown(KeyCode.Space))
        {
            //Add a force o the rigidbody2D
            //This will add an upward foce * jumHeight
            //ForceMode2D.Impulse means it will add the force the same fame it si called
            rb2d.AddForce(Vector2.up * jumpHeight, ForceMode2D.Impulse);
        }

        //Add a falling force and low jump multiplier
        //If the rb2d velocity < 0, that means it isnegaive or going downwards
        if (rb2d.velocity.y < 0)
        {
            //Add the fall multiplier to the velocity
            rb2d.velocity += (Vector2.up * Physics2D.gravity.y * (fallingMultiplier - 1) * Time.deltaTime);
        }
        //If the player is moving upward (they jumped) and are no longer pressng the key. This means they tapped the key
        else if (rb2d.velocity.y > 0 & !Input.GetKey(KeyCode.Space))
        {
            rb2d.velocity += (Vector2.up * Physics2D.gravity.y * (lowjumpMultiplier - 1) * Time.deltaTime);
        }
    }

    // -------------------- ADDED FOR POWERUP --------------------
    // This method will trigger when our player enters a trigger collider
    // (assuming the powerup has a Collider2D set to "Is Trigger" and tag "Powerup").
    private void OnTriggerEnter2D(Collider2D other)
    {
        // Check if it's the powerup AND we haven't collected one already
        if (other.CompareTag("Powerup") && !hasPowerup)
        {
            hasPowerup = true;
            // Double the jumpHeight
            jumpHeight *= 2f;
            Debug.Log("Powerup collected! Jump height is now: " + jumpHeight);

            // Destroy the powerup object so it can't be collected again
            Destroy(other.gameObject);
        }
    }
    // -----------------------------------------------------------
}
