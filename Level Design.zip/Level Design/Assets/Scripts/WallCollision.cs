using UnityEngine;
using UnityEngine.SceneManagement;

public class WallCollision : MonoBehaviour
{
    // This method is called when another collider makes contact with this collider.
    private void OnCollisionEnter2D(Collision2D collision)
    {
        // Check if the colliding object is tagged as "Player"
        if (collision.gameObject.CompareTag("Player"))
        {
            // Load the finish scene
            SceneManager.LoadScene("FinishScene");
        }
    }
}
